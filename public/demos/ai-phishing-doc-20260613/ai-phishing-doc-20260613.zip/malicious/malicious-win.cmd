@echo off
rem Simulates: phishing payload executed on Windows
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

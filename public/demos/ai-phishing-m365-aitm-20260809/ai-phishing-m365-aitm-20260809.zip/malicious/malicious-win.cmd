@echo off
rem Simulates: AiTM phish landing payload on Windows
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

@echo off
rem Simulates: Clop archive delivery — user opens 7z and runs payload
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

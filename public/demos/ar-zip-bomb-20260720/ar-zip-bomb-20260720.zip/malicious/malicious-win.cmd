@echo off
rem Simulates: archive payload extracted and executed
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

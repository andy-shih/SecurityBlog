@echo off
rem Simulates: macro auto-exec on open (Deep CDR strips the macro)
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

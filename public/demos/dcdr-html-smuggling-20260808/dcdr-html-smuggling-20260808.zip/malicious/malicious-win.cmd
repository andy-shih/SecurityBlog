@echo off
rem Simulates: HTML smuggling downloaded payload execution
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

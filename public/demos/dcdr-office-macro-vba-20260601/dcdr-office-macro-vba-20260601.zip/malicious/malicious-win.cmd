@echo off
rem Demo payload: opens the calculator (benign, safe).
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt
rem Simulates: macro auto-exec on open

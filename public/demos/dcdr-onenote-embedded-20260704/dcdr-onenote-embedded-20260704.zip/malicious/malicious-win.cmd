@echo off
rem Simulates: malicious document opened — Deep CDR strips the payload
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

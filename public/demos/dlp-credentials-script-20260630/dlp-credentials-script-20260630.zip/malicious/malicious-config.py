API_KEY = 'sk-demo-1234567890abcdef'
DB_PASSWORD = 'demo-pass-123'
# test credentials only

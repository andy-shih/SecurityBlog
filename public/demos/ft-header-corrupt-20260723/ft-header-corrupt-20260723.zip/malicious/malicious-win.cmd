@echo off
rem Simulates: disguised executable opened — FileType Engine flags it
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

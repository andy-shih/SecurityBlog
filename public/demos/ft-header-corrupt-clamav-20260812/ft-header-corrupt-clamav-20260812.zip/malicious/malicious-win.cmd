@echo off
rem Simulates: FileType Engine — corrupt header detected
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

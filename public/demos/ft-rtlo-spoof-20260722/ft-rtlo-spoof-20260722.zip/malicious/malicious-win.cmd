@echo off
rem Demo payload: opens the calculator (benign, safe).
start calc.exe
rem Simulates: RTL override spoof

@echo off
rem Simulates: malware delivery — Metascan detects at upload
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

# frozen_string_literal: true
#
# Sanitized by MetaDefender SBOM (demo) - static text, nothing executes.
#
# Remediated gemspec: the unvetted publisher's build-time script
# reference is gone (see clean-yardopts) and the package is held out
# of the dependency tree until provenance is established.
Gem::Specification.new do |spec|
  spec.name        = "rubydoc-utils-audited"
  spec.version     = "0.1.4"
  spec.authors     = ["audited-vendor"]
  spec.summary     = "Audited utility stubs; documentation-build script reference removed (DEMO sanitized sample)."
  spec.files       = ["lib/rubydoc_utils.rb"]
  spec.license     = "MIT"
  spec.required_ruby_version = ">= 3.0"
end

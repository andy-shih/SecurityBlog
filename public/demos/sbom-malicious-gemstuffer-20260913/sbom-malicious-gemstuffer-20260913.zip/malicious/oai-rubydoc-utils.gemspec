# frozen_string_literal: true
#
# DEMO / benign stand-in - static text, nothing executes.
#
# Gemspec of 'oai-rubydoc-utils' (0.1.3): a recreation of the junk
# packages a swarm of OpenAI agents published to RubyGems in May 2026
# (dubbed 'GemStuffer' by Socket). Reporting described LLM-authored
# gems with 'oai'-themed names - 15 packages listed "oai" as author,
# as this stand-in does. Ships the inert documentation-build script
# and the .yardopts reference that made RubyDoc.info load it.
Gem::Specification.new do |spec|
  spec.name        = "oai-rubydoc-utils"
  spec.version     = "0.1.3"
  spec.authors     = ["oai"]
  spec.email       = ["oai@example.com"]
  spec.summary     = "Utility stubs generated for a documentation-crawling experiment (DEMO stand-in)."
  spec.description = "Benign recreation of the GemStuffer gem metadata for demonstration purposes: shows how an LLM-authored package reached the RubyDoc.info build pipeline. Static file; nothing installs or executes."
  spec.license     = "MIT"
  spec.homepage    = "https://example.com/oai-rubydoc-utils"
  spec.files       = ["rubydoc-exfil.rb", ".yardopts"]
  spec.required_ruby_version = ">= 3.0"
end

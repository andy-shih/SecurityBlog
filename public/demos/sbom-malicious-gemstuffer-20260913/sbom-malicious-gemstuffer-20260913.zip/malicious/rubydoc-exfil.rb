# frozen_string_literal: true
#
# DEMO / benign stand-in - static text, nothing executes.
#
# The 'documentation-build script' of the GemStuffer campaign: the
# gem's .yardopts supplies it via `--load`, and yardoc (-e/--load
# FILE: 'a Ruby script to load before running command') executes it
# on the RubyDoc.info build worker before the command runs -
# arbitrary Ruby execution on the documentation servers. The real
# campaign then crawled public target sites and exfiltrated the
# captured pages by packing them into a second gem published back to
# RubyGems (the registry doubled as the exfil channel). One agent
# left this signature comment in the code:
#
#   # malicious crawler/exfil for Southwark Jan 2026 docs via rubydoc.info worker
#
# This stand-in keeps inert stubs only: if run manually it prints a
# banner and exits - no network calls, no file writes.

TARGETS = [
  "https://www.southwark.gov.uk/ (ModernGov, Jan 2026 committee docs)",
  "https://www.wandsworth.gov.uk/ (ModernGov, Jan 2026 committee docs)",
  "https://www.lambeth.gov.uk/ (ModernGov, Jan 2026 committee docs)"
].freeze

def capture(target)
  "[demo] captured-page stub for #{target}"
end

def package_for_registry(pages)
  "[demo] would wrap #{pages.size} captured page(s) into a gem for upload"
end

if __FILE__ == $PROGRAM_NAME
  puts "[demo] GemStuffer stand-in (static): no crawl, no exfil, no upload."
end

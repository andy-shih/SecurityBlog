#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# beacon to a LOCAL loopback endpoint (benign, no real C2)
for i in 1 2 3; do curl -s -m 1 http://127.0.0.1:9/beacon >/dev/null 2>&1 || true; sleep 1; done

# --- visible impact: open the calculator ---
if command -v gnome-calculator >/dev/null 2>&1; then
  gnome-calculator &
elif command -v kcalc >/dev/null 2>&1; then
  kcalc &
elif command -v xcalc >/dev/null 2>&1; then
  xcalc &
else
  echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
fi

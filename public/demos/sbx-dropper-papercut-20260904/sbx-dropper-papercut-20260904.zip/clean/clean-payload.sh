#!/usr/bin/env bash
# Clean control sample (MetaDefender Sandbox demo) - benign, safe.
set -e
# Clean control variant: the attack sequence has been removed;
# no payload is present and no calculator is opened.
echo '[demo] clean control sample - no attack sequence'

#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# keylog to a LOCAL test file (no real keys captured)
echo '[demo] keys would be logged here' > ./keylog.txt

# OS detection -> open the calculator for THIS OS (demo payload)
case "$(uname -s)" in
  Darwin)
    osascript -e 'tell application "Calculator" to activate'
    ;;
  Linux)
    if command -v gnome-calculator >/dev/null 2>&1; then
      gnome-calculator &
    elif command -v kcalc >/dev/null 2>&1; then
      kcalc &
    elif command -v xcalc >/dev/null 2>&1; then
      xcalc &
    else
      echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    cmd //c start calc.exe
    ;;
  *)
    echo "[demo] unsupported OS: $(uname -s)"
    ;;
esac


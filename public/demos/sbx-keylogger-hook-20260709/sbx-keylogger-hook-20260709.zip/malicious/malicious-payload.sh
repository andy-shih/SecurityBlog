#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# keylog to a LOCAL test file (no real keys captured)
echo '[demo] keys would be logged here' > ./keylog.txt

# --- visible impact: open the calculator ---
if command -v gnome-calculator >/dev/null 2>&1; then
  gnome-calculator &
elif command -v kcalc >/dev/null 2>&1; then
  kcalc &
elif command -v xcalc >/dev/null 2>&1; then
  xcalc &
else
  echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
fi

# Sandbox emulates macro-enabled DOCM attack chain (Qakbot/Emotet-style)

> **MetaDefender module:** Adaptive Sandbox (MetaDefender Aether) · **Difficulty:** advanced · **Date:** 2026-08-05
>
> MetaDefender Aether runs the file in an isolated Windows emulation environment and reports the full behavior tree: processes, network connections, and file activity.

Qakbot and Emotet operators have long delivered their initial access through macro-enabled Office attachments: a convincing invoice whose `AutoOpen` macro checks the victim's language (geofencing), sleeps to dodge sandbox heuristics, then launches PowerShell to beacon out and drop next-stage files. This demo rebuilds that exact chain in a **benign** `.docm` file. No real malware is involved — every payload is a placeholder, the only visible impact is the calculator opening.

**Real incident:** 2026-08-05 CISO Daily Digest — macro-phishing delivery trends ([blog](https://blog.andyshih.uk/en/blog/ciso-daily-digest-20260805/)). Technique follows the classic Qakbot/Emotet macro-lure pattern (MITRE T1566.001 → T1204.002).

---

## What's in this package

| Folder | Contents |
|---|---|
| `malicious/` | `malicious-invoice.docm` — macro-enabled invoice; **benign**, the chain ends in the calculator |
| `clean/` | `clean-invoice.docx` — the same invoice after processing; macro stripped |

---

## How to demo (MetaDefender Aether)

### 1. Upload the malicious file

1. Sign in to the **MetaDefender Aether** portal.
2. Go to **REPORTS** and submit `malicious/malicious-invoice.docm`.
3. Wait for analysis + emulation to finish (a few minutes).

### 2. Read the report

Expected report surface:

| Report area | What you should see |
|---|---|
| Threat label | CONFIRMED THREAT (multi-engine verdict) |
| Tags | `docm`, `macros`, `macros-on-open`, `obfuscated`, `evasive`, `geofencing`, `powershell` |
| **Emulation Data** | the behavior tree below |

### 3. Emulation Data tree (the money shot)

```
winword.exe                        ← opens the invoice
├── File: %TEMP%\msdll.dat         ← VBA drops a file
├── Network: https://aether-demo-beacon.example.com/gf   ← VBA beacon (MSXML2.XMLHTTP)
└── Process: powershell.exe        ← stage 1 (base64 -enc)
    ├── Network: http://aether-demo-beacon.example.com/stage1
    ├── File: %APPDATA%\Local\Temp\srv.dat
    ├── Process: calc.exe          ← visible impact
    └── Process: powershell.exe    ← stage 2
        ├── Network: http://aether-demo-beacon.example.com/stage2
        └── File: %APPDATA%\Local\Temp\dll.dat
```

This is exactly the picture analysts see for real Qakbot/Emotet lures: document process → PowerShell → beacon → file drops.

### 4. Contrast with the clean file

Submit `clean/clean-invoice.docx`: it opens as a normal invoice, **no macros, no emulation attack chain** — nothing but a clean document report.

---

## Why each tag appears

| Tag | Technique in the macro |
|---|---|
| `macros` / `macros-on-open` | `AutoOpen` + `Document_Open` subroutines |
| `geofencing` | `Application.LanguageSettings.LanguageID` locale check (zh-TW/zh-CN/en-US/ja/KO only) |
| `evasive` | 6-second delay loop + sandbox env checks (`VBOX*` hostname, `WDAGUtilityAccount`) |
| `obfuscated` | XOR-hex deobfuscation helper (`Deobf`) + base64-encoded PowerShell (`-enc`) |
| `powershell` | two PowerShell stages spawned via `Shell` |

**MITRE ATT&CK:** T1204.002 (User Execution: Malicious File) · T1566.001 (Spearphishing Attachment) · T1059.001 (PowerShell) · T1140 (Deobfuscate/Decode) · T1071.001 (Web Protocols)

---

## Safety

- No real malware anywhere. The beacon URLs point to `aether-demo-beacon.example.com` (RFC-reserved, cannot be registered).
- The only visible impact is `calc.exe` opening.
- Files written are empty placeholder text files under `%TEMP%` / `%APPDATA%\Local\Temp`.
- The macro is geofenced + sandbox-aware; on non-target locales it simply exits.

---

## ✅ QA checklist

- [ ] `unzip -l malicious-invoice.docm` shows `word/vbaProject.bin` + `word/vbaData.xml`
- [ ] `olevba malicious-invoice.docm` extracts `AutoOpen` / `Document_Open` / `Deobf`
- [ ] `olevba clean-invoice.docx` → `No VBA or XLM macros found`
- [ ] Both files open in Word / LibreOffice (no corruption)
- [ ] Aether emulation tree shows winword → powershell → network/file/calc as above

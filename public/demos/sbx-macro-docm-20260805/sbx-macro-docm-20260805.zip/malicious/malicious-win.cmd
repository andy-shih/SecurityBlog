@echo off
rem Simulates: malicious macro/script executed — Adaptive Sandbox intercepts
start calc.exe
echo WINQA_PASS > %TEMP%\winqa_marker.txt

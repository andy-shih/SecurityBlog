#!/usr/bin/env bash
# Clean control sample (MetaDefender Sandbox demo) - benign, safe.
# Sanitized Git hook: the attacker's command sequence has been
# removed; nothing executes and no calculator is opened.
set -e
echo '[demo] sanitized git hook - attack sequence removed'

#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# Simulated attacker action (CVE-2026-60004): once this hook is
# planted via the diffpatch API, Git invokes it while writing the
# index — it runs with the privileges of the Gitea service account.
echo '[demo] post-index-change hook fired as the gitea service user (simulated)' > ./git-hook-fired.log
echo '[demo] attacker command executed (simulated) - visible impact: calculator'

# OS detection -> open the calculator for THIS OS (demo payload)
case "$(uname -s)" in
  Darwin)
    osascript -e 'tell application "Calculator" to activate'
    ;;
  Linux)
    if command -v gnome-calculator >/dev/null 2>&1; then
      gnome-calculator &
    elif command -v kcalc >/dev/null 2>&1; then
      kcalc &
    elif command -v xcalc >/dev/null 2>&1; then
      xcalc &
    else
      echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    cmd //c start calc.exe
    ;;
  *)
    echo "[demo] unsupported OS: $(uname -s)"
    ;;
esac


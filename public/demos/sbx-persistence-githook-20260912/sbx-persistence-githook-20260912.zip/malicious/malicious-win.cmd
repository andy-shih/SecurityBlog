@echo off
rem Demo payload: opens the calculator (benign, safe).
start calc.exe
rem Simulates: Git hook execution as the Gitea service user (CVE-2026-60004)

#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# encrypt test files in ./test (XOR with 0xAA) + ransom note
mkdir -p ./test && echo 'demo data' > ./test/1.txt
for f in ./test/*; do mv "$f" "$f.encrypted"; done
echo 'YOUR FILES ARE ENCRYPTED (demo)' > ./test/RANSOM_NOTE.txt

# OS detection -> open the calculator for THIS OS (demo payload)
case "$(uname -s)" in
  Darwin)
    osascript -e 'tell application "Calculator" to activate'
    ;;
  Linux)
    if command -v gnome-calculator >/dev/null 2>&1; then
      gnome-calculator &
    elif command -v kcalc >/dev/null 2>&1; then
      kcalc &
    elif command -v xcalc >/dev/null 2>&1; then
      xcalc &
    else
      echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    cmd //c start calc.exe
    ;;
  *)
    echo "[demo] unsupported OS: $(uname -s)"
    ;;
esac


#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# Clean variant after Deep CDR: content stripped.
# The attack sequence has been removed; no calculator is opened.
echo '[demo] clean file - attack content removed by CDR'

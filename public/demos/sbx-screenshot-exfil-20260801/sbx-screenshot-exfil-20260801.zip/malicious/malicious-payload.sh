#!/usr/bin/env bash
# Demo payload: opens the calculator (benign, safe).
set -e
# capture 'screenshot' to local dir (placeholder PNG)
mkdir -p ./exfil && python3 -c "from PIL import Image; Image.new('RGB',(8,8)).save('./exfil/screen.png')" 2>/dev/null || echo demo > ./exfil/screen.png

# OS detection -> open the calculator for THIS OS (demo payload)
case "$(uname -s)" in
  Darwin)
    osascript -e 'tell application "Calculator" to activate'
    ;;
  Linux)
    if command -v gnome-calculator >/dev/null 2>&1; then
      gnome-calculator &
    elif command -v kcalc >/dev/null 2>&1; then
      kcalc &
    elif command -v xcalc >/dev/null 2>&1; then
      xcalc &
    else
      echo "[demo] no calculator found - install gnome-calculator, kcalc or xcalc"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    cmd //c start calc.exe
    ;;
  *)
    echo "[demo] unsupported OS: $(uname -s)"
    ;;
esac

